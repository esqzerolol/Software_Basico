static int b = 10;

void fill_a(int *ptr)
{

    *ptr = 100;
}

int get_b()
{

    return b;
}