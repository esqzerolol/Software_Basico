// Função não existe

int fake(int v);



int sum(int v) {

  return v+2;

}



int process(int x) {

  return fake(x);

}