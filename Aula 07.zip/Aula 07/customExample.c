#include <stdio.h>

struct X
{

  char a;
  long b;
  char c;
  long d;
  char e;
};

//       campos: a           b       c

struct X varx = {
  0xA1, 
  0xB1B2B3B4B5B6B7B8, 
  0xC1,
  0xD1D2D3D4D5D6D7D8,
  0xE1
};

void dump(void *p, int n)
{

  unsigned char *p1 = p;

  while (n--)
  {

    printf("%p - 0x%02X\n", p1, *p1);

    p1++;
  }
}

int main()
{
  printf ("%d\n", sizeof(varx));
  dump(&varx, sizeof(varx));

  return 0;
}