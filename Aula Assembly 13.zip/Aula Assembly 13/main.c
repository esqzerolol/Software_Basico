#include <stdlib.h>

#include <stdio.h>



void reader(long verbose);



int main()

{

   reader(1);

   return 0;

}