#ifndef AUX_H

#define AUX_H

struct Object
{

    int type;

    long ID;

    char name[16];
};


struct Person   // Align 8 | 
{

    int type; // -48

    long ID; // -40

    char name[16]; // -32

    int age; // -16
};

struct Car
{

    int type; // -96

    long ID; // -88 

    char name[16]; // -80

    char color[8]; // -64
};

void readPerson(struct Person *ptr, int *id);

void readCar(struct Car *ptr, int *id);

#endif