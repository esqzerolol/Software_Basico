#ifndef PROD_H

#define PROD_H

struct produto_s
{

    int id;

    double value;
};

typedef struct produto_s produto_t;

#endif