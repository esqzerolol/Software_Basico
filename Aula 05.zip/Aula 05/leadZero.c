#include <stdio.h>

int leading_zeros(unsigned short n);

int main (){

	printf("%u\n", leading_zeros(0)); // 16 zeros

	printf("%u\n", leading_zeros(0x0083)); // 8 zeros

	printf("%u\n", leading_zeros(0x0607)); // 5 zeros

	printf("%u\n", leading_zeros(24432)); // 1 zeros

	printf("%u\n", leading_zeros(0xC2A4)); // zeros

	return 0;
}


int leading_zeros(unsigned short n){
	for (int i = 0; i < sizeof(unsigned short)*8; i++){
		if (n & 0x8000) return i;
		else n = n << 1;
	}
	return 16;
}