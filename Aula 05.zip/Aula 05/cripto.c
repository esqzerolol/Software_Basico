#include <stdio.h>

unsigned char rotate_left(unsigned char x, int n);

int main (){

  printf("%u\n",rotate_left(0x61, 1));
  printf("%u\n",rotate_left(0x61, 2));
  printf("%u\n",rotate_left(0x61, 7));

  return 0;
}

unsigned char rotate_left(unsigned char x, int n){
  char copyMask = 0x80;
  copyMask = copyMask >> n;
  unsigned char buffer;
  buffer = x & copyMask;
  buffer = buffer >> (8-n);
  x = x << n;
  x = x | buffer;
  return x;
}