void show(int *vet, int size);

int vet[7] = {1, 2, 3, 0, 4, 5, 0};

int main()
{

  show(vet, 7);

  return 0;
}