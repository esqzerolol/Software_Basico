#include <stdio.h>

void show(int *v, int size)
{

  int i;

  for (i = 0; i < size; i++)

    printf("%d\n", v[i]);
}