#include <stdio.h> 



void sayHello() 

{ 

   printf("Muito bom!\n");

}