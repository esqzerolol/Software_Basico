#include <stdio.h> 

int main(){ 
    
  printf("Laboratorio 01\n"); 
  return 0; 

}