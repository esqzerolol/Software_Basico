#include <stdio.h> 



void sayHello();



int main() 

{ 

  sayHello();

  return 0; 

}