int s = 0;

int nums[4] = {65, -105, 111, 34};

void sum()

{

  int i = 0;

  while (i < 4)
  {

    s = s + nums[i];

    i++;
  }
}