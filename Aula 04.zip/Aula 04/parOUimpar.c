#include <stdio.h>



int odd_ones(unsigned int x) {

  int NumDe1 = 0;
  for (int i = 0; i < (sizeof(unsigned int)*8); i++){
    if (x & 0x00000001) {NumDe1++;}
    x = x >> 1;
  }

  // Jeito paia
  // if (!(NumDe1 & 0x00000001)) return 0;
  // else return 1;

  // Jeito chique
  return (NumDe1 & 0x00000001) ? 1 : 0;

}



int main() {

  unsigned int v;



  v = 0x01010101;

  printf("%X tem número %s de bits\n", v, odd_ones(v) ? "impar" : "par");



  v = 0x01030101;

  printf("%X tem número %s de bits\n", v, odd_ones(v) ? "impar" : "par");



  return 0;

}