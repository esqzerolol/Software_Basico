#ifndef DATA_H

#define DATA_H

struct data
{

    int len;

    long elems[5];
};

#endif