#include <stdio.h>

int fat(int n);

int main(void)
{

  printf("%d\n", fat(5));

  return 0;
}