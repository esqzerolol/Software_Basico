void filli(int *v, int cols, int k);

void fills(short *v, int cols, int k);

int calc()

{

    int i = 0; // Deve ser registrador

    int j = 4; // Deve ser registrador

    int sum;

    int vet1[5];

    short vet2[5];

    filli(vet1, 5, i);

    fills(vet2, 5, j);

    sum = 0;

    for (; i < 5; i++, j--)
    {

        sum += vet1[i] + vet2[j];
    }

    return sum;
}

#include <stdio.h>

int calc();

void filli(int *v, int cols, int k)

{

    int i;

    (void)k;

    for (i = 0; i < cols; i++)
    {

        v[i] = 1;
    }
}

void fills(short *v, int cols, int k)

{

    int i;

    (void)k;

    for (i = 0; i < cols; i++)
    {

        v[i] = 2;
    }
}

int main()

{

    printf("%d\n", calc());

    return 0;
}